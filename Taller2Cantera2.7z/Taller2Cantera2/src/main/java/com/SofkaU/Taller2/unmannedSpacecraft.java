package com.SofkaU.Taller2;

public class unmannedSpacecraft extends Ship {

    /**
     * Se crea unm etodo publico relacioando al estudio que puede realizar la
     * nave
     */
    public void Study() {
        System.out.println("Que estudios es capaz de realizar la nave?");
        String studies = entry.nextLine();
        System.out.println("cúal es la distancia máxima que puede recorrer?");
        int distance = entry.nextInt();
        System.out.println("Cúal es la carga útil de materiales que puede almacenar, en toneladas?");
        int chargeU = entry.nextInt();
        System.out.println("La nave esta en la capacidad de realiazar los siguientes estudios: "
                + studies + " y puede recorrer un distancia de: " + distance + ", la cúal puede almacenar "
                + chargeU + "T");
        System.out.println("");
    }

    /**
     * Implemento el metodo extendido desde la clase Ship
     *
     * @return los atributos referentes a la misión de la nave
     */
    @Override
    public void mision() {
        System.out.println("Cúal es la misión de la nave?");
        String goal = entry.nextLine();
        System.out.println("cúal es la carga útil de la nave en toneladas?");
        int charge = entry.nextInt();
        System.out.println("Cúal es la velocidad de desplazamiento en orbita,Km/h ?");
        int speed = entry.nextInt();
        System.out.println("Estudiara algún cuerpo celeste, de ser así indique cual ?");
        String body = entry.nextLine();
        System.out.println("La misión de la nave es: " + goal + " el vehiculo no tripulado"
                + "cuneta con una carga útil de: " + charge + "T, con una velocidad de desplazamiento de "
                + speed + "Km/h. Cuerpo celeste estudiado:  " + body);
        System.out.println("");
    }

    /**
     * Implemento el metodo extendido desde la clase Ship
     *
     * @return los atributos referentes a la hoja de vida de la nave
     */
    @Override
    public void lifeSheet() {
        System.out.println("Cúantos años en servicio tiene la nave?");
        int time = entry.nextInt();
        System.out.println("Donde fue fabricada?");
        String developed = entry.nextLine();
        System.out.println("Cúantos mantenimientos se realizan al año?");
        int maintenance = entry.nextInt();
        System.out.println("Que empresa realiza estos mantenimientos?");
        String company = entry.nextLine();
        System.out.println("La nave lleva en servicio " + time + " años y fue fabricada en "
                + developed + ". Se le realizan " + maintenance + " mantenimientos "
                + "al año, realizados por la compañia " + company);
        System.out.println("");
    }

    /**
     * Implemento el metodo extendido desde la clase Ship
     *
     * @return los atributos referentes al tpo de combustible usado por la nave
     */
    @Override
    public void typeFuel() {
        System.out.println("Que combustible se usa para su propulsión?");
        String fuel = entry.nextLine();
        System.out.println("Que proporción de combustible emplea?");
        String proportion = entry.nextLine();
        System.out.println("Que porcentaje de perdida presenta?");
        int loss = entry.nextInt();
        System.out.println("Para la puesta en orbita de la nave se usa " + fuel + " como combustible "
                + " en una proporcion de" + proportion + ", con un porcentaje de perdida de"
                + loss + " por galón. ");
        System.out.println("");
    }
}
