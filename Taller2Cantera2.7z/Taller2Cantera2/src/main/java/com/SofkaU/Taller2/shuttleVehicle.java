package com.SofkaU.Taller2;

public class shuttleVehicle extends Ship {

    /**
     * Implemento el metodo name extendido desde la clase Ship
     *
     * @return name
     */
    @Override
    public String name() {
        System.out.println("Cúal es el nombre de la nave");
        String name = entry.nextLine();
        return name;
    }

    /**
     * Implemento el metodo name extendido desde la clase Ship
     *
     * @return name
     */
    @Override
    public String owner() {
        System.out.println("Que País construyo la nave?");
        String owner = entry.nextLine();
        return owner;
    }

    /**
     * Implemento el metodo extendido desde la clase Ship
     *
     * @return los atributos referentes a la misión de la nave
     */
    @Override
    public void mision() {
        System.out.println("Cúal es la carga del vehiculo lanzadero ?");
        String cargo = entry.nextLine();
        System.out.println("Cúal es la potencia de los cohetes?");
        int power = entry.nextInt();
        System.out.println("Cúal es su autonomia?");
        int autonomy = entry.nextInt();
        System.out.println("Cúal es la carga util del vehiculo?");
        int load = entry.nextInt();
        System.out.println("El vehiculo lanzadera lleva como carga un: " + cargo
                + ", para dejar esta carga en el espacio, cuenta con una potencia de"
                + " propulsión de " + power + "con una autonomia de :  " + autonomy 
                + " siendo capaz de llevar fuera de la atmosfera una carga total de: "
                + load);
        System.out.println("");
    }

    /**
     * Implemento el metodo extendido desde la clase Ship
     *
     * @return los atributos referentes a la hoja de vida de la nave
     */
    @Override
    public void lifeSheet() {
        System.out.println("Cúantos años en servicio tiene la nave?");
        int time = entry.nextInt();
        System.out.println("Donde fue fabricada?");
        String developed = entry.nextLine();
        System.out.println("Cúantos mantenimientos se realizan al año?");
        int maintenance = entry.nextInt();
        System.out.println("Que empresa realiza estos mantenimientos?");
        String company = entry.nextLine();
        System.out.println("La nave lleva en servicio " + time + " años y fue fabricada en "
                + developed + ". Se le realizan " + maintenance + " mantenimientos "
                + "al año, realizados por la compañia " + company);
        System.out.println("");
    }

    /**
     * Implemento el metodo extendido desde la clase Ship
     *
     * @return los atributos referentes al tpo de combustible usado por la nave
     */
    @Override
    public void typeFuel() {
        System.out.println("Que combustible se usa para su propulsión?");
        String fuel = entry.nextLine();
        System.out.println("Que proporción de combustible emplea?");
        String proportion = entry.nextLine();
        System.out.println("Que porcentaje de perdida presenta?");
        int loss = entry.nextInt();
        System.out.println("Para la puesta en orbita de la nave se usa " + fuel + " como combustible "
                + " en una proporcion de" + proportion + ", con un porcentaje de perdida de"
                + loss + " por galón. ");
        System.out.println("");
    }
}
