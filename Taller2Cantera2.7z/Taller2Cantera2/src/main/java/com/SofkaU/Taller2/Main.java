package com.SofkaU.Taller2;

import java.util.Scanner;

/**
 *
 * @author juans
 */
public class Main {

    public static void main(String[] args) {

        Scanner entry = new Scanner(System.in);

        int option = 0;
        /**
         * El menú se realizó en con un do-while, el cuál se repetirá hasta que
         * se seleccione la opción de salir.
         */
        do {
            /**
             * Impresión del menú
             */
            System.out.println("Seleccione una opción");
            System.out.println("1.Crear Nave Lanzadera");
            System.out.println("2.Crear Nave No Tripulada");
            System.out.println("3.Crear Nave Tripulada Lanzada Por EEUU");
            System.out.println("4.Crear Nave Tripulada");
            System.out.println("0.Salir");
            /**
             * Captura el valor seleccionado del menú.
             */
            option = entry.nextInt();
            /**
             * Validación de que sea una opción válida.
             */
            if (option < 5) {

                /**
                 * Se crea la nave, dependiendo de la opción seleccionada por el
                 * usuario
                 */
                switch (option) {
                    /**
                     * Primera opción del menú.
                     */
                    case 1:
                        shuttleVehicle ship = new shuttleVehicle();
                        ship.name();
                        ship.owner();
                        ship.mision();
                        ship.lifeSheet();
                        ship.typeFuel();
                        break;
                    /**
                     * Segunda opción del menú.
                     */
                    case 2:
                        unmannedSpacecraft shipU = new unmannedSpacecraft();
                        shipU.Study();
                        shipU.name();
                        shipU.owner();
                        shipU.mision();
                        shipU.lifeSheet();
                        shipU.typeFuel();
                        break;
                    /**
                     * Tercera opción del menú.
                     */
                    case 3:
                        mannedSpacecraft shipA = new mannedSpacecraft();
                        System.out.println("Año de lanzamiento");
                        String start = entry.next();
                        System.out.println("Desde que base fue lanzado?");
                        String base = entry.next();
                        System.out.println("Año de cese de funcionamiento (si sigue funcionando, se escribe 'actualidad')");
                        String end = entry.nextLine();
                        shipA.name();
                        shipA.owner();
                        shipA.mision();
                        shipA.lifeSheet();
                        shipA.typeFuel();
                        System.out.println("Año de lanzamiento "+start+ " lanzado desde" +base+" ceso funciones en el año de:"
                        +end+ " si dice actualidad es porque aun esta en operación");
                        break;
                    /**
                     * Cuarta opción del menú.
                     */
                    case 4:
                        mannedSpacecraft shipM = new mannedSpacecraft();
                        System.out.println("Año de la misión");
                        String year = entry.next();
                        System.out.println("Indique las nacionalidades de la tripulación");
                        String countries = entry.next();
                        System.out.println("Indique el periodo de entrenamiento para la misión");
                        String time = entry.next();
                        shipM.name();
                        shipM.owner();
                        shipM.mision();
                        shipM.lifeSheet();
                        shipM.typeFuel();
                        System.out.println("Año de misión "+year+ ", la tripulacion tiene nacionalidades" +countries
                                +" y tuvo un periodo de preparación para la mision de "+time);
                        break;
                    /**
                     * Opción cero del menú.
                     */
                    case 0:
                        System.out.println("Saliendo ...");
                        break;
                    default:
                        throw new AssertionError();
                }
            } else {
                System.out.println("Escoja una opción válida");
            }
        } while (option != 0);
    }
}
