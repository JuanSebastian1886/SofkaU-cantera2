
package com.SofkaU.Taller2;

public class mannedSpacecraft extends Ship {
    /**
    * Implemento el metodo name extendido desde la clase Ship
    * @return name
    */
    @Override
    public String name() {
        System.out.println("Cúal es el nombre de la nave");
        String name=entry.nextLine();
        return name;
    }
   /**
    * Implemento el metodo name extendido desde la clase Ship
    * @return name
    */
    @Override
    public String owner() {
        System.out.println("Que País construyo la nave?");
        String owner=entry.nextLine();
        return owner;
    }    
    /**
     * Implemento el metodo extendido desde la clase Ship
     * @return los atributos referentes a la misión de la nave
     */
    @Override
    public void mision() {
        System.out.println("Cúal es la misión de la tripulación?");
        String goal = entry.nextLine();
        System.out.println("Cúantos miembros tiene la tripulación?");
        int crew = entry.nextInt();
        System.out.println("Cúantos miembros de la tripulación son hombres?");
        int crewM = entry.nextInt();
        System.out.println("Cúantos miembros de la tripulación son mujeres?");
        int crewF = entry.nextInt();
        System.out.println("La misión de la tripulación es: " + goal + ", esta compuesta por "
                + crewF + " mujeres y " + crewM + " hombres, para un total de "
                + crew + " tripulantes");
        System.out.println("");
    }

    /**
     * Implemento el metodo extendido desde la clase Ship
     * @return los atributos referentes a la hoja de vida de la nave
     */
    @Override
    public void lifeSheet() {
        System.out.println("Cúantos años en servicio tiene la nave?");
        int time = entry.nextInt();
        System.out.println("Donde fue fabricada?");
        String developed = entry.nextLine();
        System.out.println("Cúantos mantenimientos se realizan al año?");
        int maintenance = entry.nextInt();
        System.out.println("Que empresa realiza estos mantenimientos?");
        String company = entry.nextLine();
        System.out.println("La nave lleva en servicio " + time + " años y fue fabricada en "
                + developed + ". Se le realizan " + maintenance + " mantenimientos "
                + "al año, realizados por la compañia " + company); 
        System.out.println("");
    }

    /**
     * Implemento el metodo extendido desde la clase Ship
     * @return los atributos referentes al tpo de combustible usado por la nave
     */
    @Override
    public void typeFuel() {
        System.out.println("Que combustible se usa para su propulsión?");
        String fuel = entry.nextLine();
        System.out.println("Que proporción de combustible emplea?");
        String proportion = entry.nextLine();
        System.out.println("Que porcentaje de perdida presenta?");
        int loss = entry.nextInt();
        System.out.println("Para la puesta en orbita de la nave se usa " + fuel + " como combustible "
                + " en una proporcion de" + proportion + ", con un porcentaje de perdida de"
                + loss + " por galón. ");
        System.out.println("");
    }
}


