package com.SofkaU.Taller2;

import java.util.Scanner;

/**
 * Se crea la clase abstracta Ship que encapsulara las funcionalidades de las
 * clases a extender
 *
 * @author juans
 */
public abstract class Ship {

    /**
     * Definición de la calse Scanner
     */
    Scanner entry = new Scanner(System.in);

    /**
     * Metodo para el atributo name
     */
    public String name() {
        System.out.println("Cúal es el nombre de la nave");
        String name=entry.nextLine();
        return name;
    }
    /**
     * Metodo para el atributo owner
     * País que la construyo y quien hace uso de la misma.
     */
    public String owner() {
        System.out.println("Que País construyo la nave?");
        String owner=entry.nextLine();
        return owner;
    }

    /**
     * Metodo abstracto que implementara la mision de cada nave
     * @return
     */
    public abstract void mision();

    /**
     * Metodo abstracto que implementara la hoja de vida de cada nave Esto se
     * entiende como la experiencia en vuelo que tiene o tuvo cada una de ellas.
     * @return 
     */
    public abstract void lifeSheet();

    /**
     * Metodo abstracto que implementara la hoja de vida de cada nave Esto se
     * entiende como la experiencia en vuelo que tiene o tuvo cada una de ellas.
     * @return 
     */
    public abstract void typeFuel();

}
